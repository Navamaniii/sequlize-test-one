var express = require("express");
var app = express();
var bodyParser = require("body-parser");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

const db = require("./config/db.config.js");

db.sequelize
  .sync({
    force: false,
  })
  .then(() => {
    console.log("Drop and Resync with { force: false }");
  });

require("./route/route.js")(app);

app.listen(7000, () => {
  console.log("app is running on port 7000");
});



