module.exports = function (app) {
  
    const ctrl = require("../controller/controller.js");
  
    app.post("/api/addagent", ctrl.createagent);
    app.post("/api/addcustomer", ctrl.createcustomer);
    app.get("/api/get/:id", ctrl.one);
    app.get("/api/get",( ctrl.all));

  };
  







