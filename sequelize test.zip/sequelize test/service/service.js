const ctrl = require("../config/db.config");
var agen = ctrl.agents;
const customer = ctrl.customers;

const Createagent = async (details) => {
  var dt = await agen.create({
    AGENT_CODE: details.AGENT_CODE,
    AGENT_NAME: details.AGENT_NAME,
    COMMISSION: details.COMMISSION,
  });
  return dt;
};
var Createcustomer = async (details) => {
 await customer.create({
    CUST_NAME: details.CUST_NAME,
    PAYMENT_AMT: details.PAYMENT_AMT,
    AGENT_CODE: details.AGENT_CODE,
  });
  return;
};













//var All = async (datas) => {
// var mt = await agen.findAll({});

// var mt=
//  (agen.hasMany(customer, {foreignKey: 'AGENT_CODE'}),
//  customer.belongsTo(agen, {foreignKey: 'AGENT_CODE'}),
//  customer.find({ where: { AGENT_CODE : AGENT_CODE}, include: [agents]}));

//  return mt;  //   var data = await agen.findAll({
//   //     include: { model: customer, required: true },
//   //     attributes: ['AGENT_CODE','AGENT_NAME','COMMISSION',
//   //     'customer.PAYMENT_AMT','customer.cust_name']
//   // });
//   // return data;
// };

module.exports = {
  Createagent,
  Createcustomer,
  // All
};
