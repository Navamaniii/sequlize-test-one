const Sequelize = require("sequelize");

const sequelize = new Sequelize("nav", "root", "", {
  host: "localhost",
  dialect: "mysql",
});

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.agents = require("../model/agent.js")(sequelize, Sequelize);
db.customers = require("../model/customer.js")(sequelize, Sequelize);

db.agents.hasMany(db.customers, {
  foreignKey: "agent_code",
  as: "customers",
});
db.customers.belongsTo(db.agents, {
  foreignKey: "agent_code",
  as: "agents",
});

module.exports = db;
