module.exports = (sequelize, Sequelize) => {
  const agent = sequelize.define(
    "agents",
    {
      
      AGENT_NAME: {
        type: Sequelize.STRING(100),
        allowNull: false,
      },
      COMMISSION: {
        type: Sequelize.DECIMAL(10, 2),
      },
    },
    {
      timestamps: false,
    }
  );

  return agent;
};
