module.exports = (sequelize, Sequelize) => {
  const customer = sequelize.define(
    "customer",
    {
      CUST_NAME: {
        type: Sequelize.STRING(100),
        allowNull: false,
      },
      PAYMENT_AMT: {
        type: Sequelize.DECIMAL(12, 2),
      },
      
    },
    {
      timestamps: false,
    }
  );

  return customer;
};



// AGENT_CODE: {
//   type: Sequelize.STRING(100),
//   foreignKey: true,
// },