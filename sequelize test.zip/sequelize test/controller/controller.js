const { customers, Sequelize, agents } = require("../config/db.config");
const ctrl = require("../config/db.config");
const serv = require("../service/service");
var agen = ctrl.agents;

var express = require("express");
var app = express();
var bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var customer = ctrl.customers;

exports.createagent = async (req, res, next) => {
  const details = req.body;
  var created = await serv.Createagent(details);
  console.log(created);
  res.status(200).send("created new data");
};

exports.createcustomer = async (req, res) => {
  const details = req.body;
  var created = serv.Createcustomer(details);
  res.status(200).send("created new data");
};

exports.one = async (req, res) => {
  const data = await agen.findAll({
    where: { id: req.params.id },
    attributes: {
      include: [
        [Sequelize.fn("COUNT", Sequelize.col("CUST_NAME")), "customerCount"],
        [Sequelize.fn("sum", Sequelize.col("PAYMENT_AMT")), "total_amount"],
        [
          Sequelize.literal("SUM(PAYMENT_AMT * COMMISSION)/100"),
          "Total_commission",
        ],
      ],
    },
    include: [{ model: customer, as: "customers", attributes: [] }],
  });
  res.status(200).send(data);
};

exports.all = async (req, res) => {
  const data = await agen.findAll({
    attributes: {
      include: [
        [Sequelize.fn("COUNT", Sequelize.col("CUST_NAME")), "customerCount"],
        [Sequelize.fn("sum", Sequelize.col("PAYMENT_AMT")), "total_amount"],
        [
          Sequelize.literal("SUM(PAYMENT_AMT * COMMISSION)/100"),
          "Total_commission",
        ],
      ],
    },
    group: ["agents.id"],
    include: [{ model: customer, as: "customers", attributes: [] }],
  });

  res.status(200).send(data);
  return data;
};
